#ifndef __MY_NETWORK__
#define __MY_NETWORK__

void get_post_values( a_array *keys, a_array *values );
void create_arrays( char *data, a_array *keys, a_array *values );

#endif
