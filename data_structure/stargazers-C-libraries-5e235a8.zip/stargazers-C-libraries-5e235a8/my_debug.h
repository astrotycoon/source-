#ifndef __MY_DEBUG__
#define __MY_DEBUG__

void debug_print( int type, char *text );
void malloc_failed( void );

#define DP_DEBUG 1
#define DP_MESSAGE 2

#endif
